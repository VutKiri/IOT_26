import machine
import time
import neopixel
import uselect, sys
import BG77
import _thread
import os
import ahtx0
import random
from machine import Pin, I2C
import ujson

# --- INICIALIZÁCIA HARDVÉRU ---
i2c1 = I2C(1, scl=Pin(15), sda=Pin(14), freq=400000)
tmp_sensor = ahtx0.AHT20(i2c1)
tmp_sensor.initialize()

RGB_LEDS = neopixel.NeoPixel(machine.Pin(16), 3, bpp=4)
RGB_LEDS[0] = (10,0,0,0)
RGB_LEDS.write()

pon_trig = machine.Pin(9, machine.Pin.OUT)

#  FUNKCIE PRE JSON (temp, hum, wind)
def createJSON1():
    if module.isRegistered():
        nwinfo = module.getNWInfo()
        print("Registrovano")
        
    json_string={"RSRP":nwinfo.RSRP if nwinfo else 0, "SINR":nwinfo.SINR if nwinfo else 0, "CellID":nwinfo.CellID if nwinfo else "N/A","latitude":49.3695500,"longitude":16.8157000}
    return ujson.dumps(json_string)

def createJSON():
    ran_wind = random.randint(15, 30)
    json_string={"temperature":tmp_sensor.temperature,"humidity":tmp_sensor.relative_humidity, "windspeed":ran_wind}
    return ujson.dumps(json_string)

# INICIALIZÁCIA MODEMU 
bg_uart = machine.UART(0, baudrate=115200, tx=machine.Pin(0), rxbuf=256, rx=machine.Pin(1), timeout=0, timeout_char=1)
bg_uart.write(bytes("AT\r\n","ascii"))
time.sleep(0.5)

module = BG77.BG77(bg_uart, verbose=True, radio=False)

time.sleep(0.3)
module.sendCommand("AT+QURCCFG=\"urcport\",\"uart1\"\r\n")
time.sleep(0.1)

# Zapnutie PSM (nastavenie parametrov)
bg_uart.write(b'AT+QPSMS=1,,,"10100010","00001111"\r\n') #skušobne pre prezentáciu a testovanie 2min / 30s
#bg_uart.write(b'AT+CPSMS=1,,,"10101111","00001111"\r\n') #reálna "ostrá" verzia_1 (15min / 30s)
#bg_uart.write(b'AT+CPSMS=1,,,"10101010","00001111"\r\n') #reálna "ostrá" verzia_2 (10min / 30s)
time.sleep(1)

module.sendCommand("AT+CEDRXS=0\r\n")
time.sleep(1)
module.sendCommand("AT+QCFG=\"band\",0x0,0x80084,0x80084,1\r\n")
module.setRadio(1)
module.setAPN("lpwa.vodafone.iot")
time.sleep(3)

module.sendCommand("AT+CFUN=1\r\n")
time.sleep(3)
module.sendCommand("AT+QICSGP=1,1,\"lpwa.vodafone.iot\"\r\n")
time.sleep(3)

# --- HLAVNÁ FUNKCIA ---
def odesli_na_thingsboard():
    token = "VgEuJgBrVmg7NBmWqxl7"
    
    print("Odosielam STARTUP spravu...")
    time.sleep(2)
    module.sendCommand("AT+QIACT=1\r\n")
    time.sleep(2)
    module.sendCommand("AT+QCOAPOPEN=0,\"147.229.148.105\",5683\r\n")
    time.sleep(3)
    
    bg_uart.write(f'AT+QCOAPOPTION=0,0,0,11,\"api/v1/{token}/telemetry\"\r\n')
    time.sleep(1)
    zprava = createJSON1()
    print(zprava)
    prikaz = f'AT+QCOAPSEND=0,1,2,1,{len(zprava)}\r\n' #  0,1,2,50 pre JSON
    bg_uart.write(prikaz)
    time.sleep(1.5)
    bg_uart.write(zprava)
    bg_uart.write(b'\x1a')
    time.sleep(2)
    module.sendCommand("AT+QCOAPCLOSE=0\r\n")
    time.sleep(1)

    # HLAVNÍ SMYČKA
    while True:
        print("\nMěřeníí start")
        
        module.sendCommand("AT+QIACT=1\r\n")
        time.sleep(1)
        module.sendCommand("AT+QCOAPOPEN=0,\"147.229.148.105\",5683\r\n")
        time.sleep(3)

        bg_uart.write(f'AT+QCOAPOPTION=0,0,0,11,\"api/v1/{token}/telemetry\"\r\n')
        time.sleep(1)
        zprava = createJSON()
        print(zprava)
        
        prikaz = f'AT+QCOAPSEND=0,1,2,1,{len(zprava)}\r\n'
        bg_uart.write(prikaz)
        time.sleep(1.5)
        bg_uart.write(zprava)
        bg_uart.write(b'\x1a')
        time.sleep(2)
            
        module.sendCommand("AT+QCOAPCLOSE=0\r\n") 
        time.sleep(1)
        module.sendCommand("AT+QIDEACT=1\r\n")
        time.sleep(3)
        
        print("PSM režim spiime)")
        time.sleep(60)
        #time.sleep(900)
        #time.sleep(600)
        
        print("vstavej modul")
        pon_trig.value(1)
        time.sleep(.3)
        pon_trig.value(0)
        time.sleep(2)

# --------------------
odesli_na_thingsboard()